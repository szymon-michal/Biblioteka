import React, { useState } from 'react'
import { apiFetch } from '../lib/api'
import { auth } from '../lib/auth'
import { config } from '../lib/config'
import styles from '../styles/login.module.css'

export function LoginPage(props: { onSuccess?: () => void }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      // Many Spring JWT backends accept { username, password } and return { token } or { accessToken }.
      const res = await apiFetch<any>(config.authLoginPath, {
        method: 'POST',
        body: { username, password },
      })

      const token = res?.token || res?.accessToken || res?.jwt || res?.data?.token
      if (!token) {
        throw new Error(
          'Login succeeded but no token was found in the response. Adjust token mapping in src/pages/Login.tsx.',
        )
      }

      auth.setToken(token)
      props.onSuccess?.()
    } catch (e: any) {
      setError(e?.message || e?.details?.message || 'Login failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={styles.wrap}>
      <div className={styles.card}>
        <div className={styles.brand}>
          <div className={styles.logo} aria-hidden>
            📚
          </div>
          <div>
            <div className={styles.title}>Library</div>
            <div className={styles.subtitle}>Sign in to manage the catalog</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <label className="field">
            <span className="label">Username</span>
            <input className="input" value={username} onChange={(e) => setUsername(e.target.value)} autoFocus />
          </label>

          <label className="field">
            <span className="label">Password</span>
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>

          {error ? <div className={styles.error}>{error}</div> : null}

          <button className="button" disabled={loading || !username || !password}>
            {loading ? 'Signing in…' : 'Sign in'}
          </button>

          <div className={styles.help}>
            <div>
              API: <code>{config.apiUrl}</code>
            </div>
            <div>
              Login endpoint: <code>{config.authLoginPath}</code>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
