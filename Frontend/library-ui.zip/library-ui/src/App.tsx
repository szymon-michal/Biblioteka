import React, { useMemo } from 'react'
import { AppShell } from './components/AppShell'
import { useHashRoute } from './lib/router'
import { LoginPage } from './pages/Login'
import { DashboardPage } from './pages/Dashboard'
import { CatalogPage } from './pages/Catalog'
import { LoansPage } from './pages/Loans'
import { MembersPage } from './pages/Members'
import { ExplorerPage } from './pages/Explorer'
import { SettingsPage } from './pages/Settings'
import { auth } from './lib/auth'

export type RouteKey =
  | 'login'
  | 'dashboard'
  | 'catalog'
  | 'loans'
  | 'members'
  | 'explorer'
  | 'settings'

const routes: Record<RouteKey, React.ReactNode> = {
  login: <LoginPage />,
  dashboard: <DashboardPage />,
  catalog: <CatalogPage />,
  loans: <LoansPage />,
  members: <MembersPage />,
  explorer: <ExplorerPage />,
  settings: <SettingsPage />,
}

export function App() {
  const { route, navigate } = useHashRoute<RouteKey>('dashboard')

  const isAuthed = auth.isAuthenticated()
  const effectiveRoute: RouteKey = useMemo(() => {
    if (!isAuthed) return 'login'
    if (route === 'login') return 'dashboard'
    return route
  }, [isAuthed, route])

  if (effectiveRoute === 'login') {
    return <LoginPage onSuccess={() => navigate('dashboard')} />
  }

  return (
    <AppShell current={effectiveRoute} onNavigate={navigate}>
      {routes[effectiveRoute]}
    </AppShell>
  )
}
